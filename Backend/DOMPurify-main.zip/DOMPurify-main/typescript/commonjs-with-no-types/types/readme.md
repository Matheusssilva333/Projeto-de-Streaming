This simulates not having `@types/trusted-types` installed.
