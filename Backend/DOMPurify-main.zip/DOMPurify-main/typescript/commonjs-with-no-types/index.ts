import * as dompurify from 'dompurify';

dompurify.sanitize('<p>');
dompurify().sanitize('<p>');
